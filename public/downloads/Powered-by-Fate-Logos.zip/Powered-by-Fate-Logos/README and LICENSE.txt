We’re offering two versions of the Powered By Fate logo. Choose the one that best suits the background you’re putting it on. To make legal use of either logo, you must include the following text:

Fate™ is a trademark of Evil Hat Productions, LLC. The Powered by Fate logo is © Evil Hat Productions, LLC and is used with permission.

That’s it!

If you need to make color alterations to one of these logo options to better suit your product, please email Evil Hat at feedback@evilhat.com for permission (which is usually granted). You may not otherwise alter the logo (change its shape, use only part of it, etc).

