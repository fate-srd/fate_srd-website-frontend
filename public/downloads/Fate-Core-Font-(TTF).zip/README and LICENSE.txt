The Fate Core Font
==================
To make use of it, just give us credit as follows:

The Fate Core font is © Evil Hat Productions, LLC and is used with permission. The Four Actions icons were designed by Jeremy Keller.

This font contains a small number of glyphs, supporting Fudge Dice faces (0, +, -), the Four Actions (A, D, C, O), and some stress track boxes (using the number keys). Enjoy!